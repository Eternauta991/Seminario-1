extends Node2D

func _input(event: InputEvent) -> void:
	if Input.is_action_pressed("jugar"):
		get_tree().change_scene_to_file("res://aparte/escenario_.tscn")
